import EcommerceGrid from "@/components/ecommerce-grid";

export default function ItemsPage() {
	return (
		<>
			<EcommerceGrid />
		</>
	)
}
